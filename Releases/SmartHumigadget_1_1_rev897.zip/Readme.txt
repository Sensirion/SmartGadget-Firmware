Target:		nRF51822, BVMCN5103-BK
Filename:	SmartHumigadget_1_1_rev897.hex
Type:		Application only
Datum File:	23.03.2015
FileSize:	102'400 Bytes
Version:	1.1

16 Bit CRC:	-
32 Bit CRC:	-

NO Flash Lock
NO Read-out protection
Please add SoftDevice 7.0.0