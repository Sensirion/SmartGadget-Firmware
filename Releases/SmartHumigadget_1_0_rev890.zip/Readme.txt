Target:		nRF51822, BVMCN5103-BK
Filename:	SmartHumigadget_1_0_rev890.hex
Type:		Application only
Datum File:	19.03.2015
FileSize:	100'745 Bytes
Version:	1.0

16 Bit CRC:	-
32 Bit CRC:	-

NO Flash Lock
NO Read-out protection
Please add SoftDevice 7.0.0