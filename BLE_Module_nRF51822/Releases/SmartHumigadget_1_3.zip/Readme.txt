Target:		nRF51822, BVMCN5103-BK
Filename:	SmartHumigadget_1_3.hex
Type:		Application only
Datum File:	08.04.2016
FileSize:	102'400 Bytes
Version:	1.3

Add delay to logger download finished notification.
Change datatype of timestamp variables to uint64_t from uint32_t.